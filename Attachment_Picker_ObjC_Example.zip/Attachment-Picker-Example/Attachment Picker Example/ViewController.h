//
//  ViewController.h
//  Attachment Picker Example
//
//  Created by Mallikarjun on 09/05/18.
//  Copyright © 2018 Mallikarjun. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface ViewController : UIViewController 

@property (weak, nonatomic) IBOutlet UIImageView *sampleImage;
@property (weak, nonatomic) IBOutlet UILabel *fileNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *fileSizeLabel;

@end

