//
//  main.m
//  Attachment Picker Example
//
//  Created by Mallikarjun on 09/05/18.
//  Copyright © 2018 Mallikarjun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
